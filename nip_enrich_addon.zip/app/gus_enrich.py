
import os, re, httpx
from notion_client import Client

# --- Utilities ---

NIP_RE = re.compile(r"[^0-9]")

def clean_nip(s: str) -> str:
    s = NIP_RE.sub("", s or "")
    return s if len(s) == 10 else ""

def page_id_from_url(url: str) -> str:
    if not url:
        return ""
    m = re.search(r"([0-9a-f]{32})", url.replace("-", ""))
    if m:
        return m.group(1)
    m2 = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})", url, re.I)
    return m2.group(1) if m2 else ""

async def fetch_gus(nip: str) -> dict | None:
    base = os.getenv("OFFICEBLOG_API_BASE", "https://api.officeblog.pl/gus.php")
    url = f"{base}?NIP={nip}&format=2"
    async with httpx.AsyncClient(timeout=20) as cx:
        r = await cx.get(url)
        r.raise_for_status()
        d = r.json()
        # Normalize keys defensively
        return {
            "firma": d.get("Nazwa") or d.get("nazwa") or "",
            "regon": d.get("REGON") or d.get("regon") or "",
            "pkd":   d.get("PKD") or d.get("pkd") or "",
            "ulica": d.get("Ulica") or d.get("ulica") or "",
            "kod":   d.get("KodPocztowy") or d.get("kod_pocztowy") or "",
            "miasto": d.get("Miejscowosc") or d.get("miasto") or "",
            "woj":   d.get("Wojewodztwo") or d.get("wojewodztwo") or "",
        }

def rtext(val: str):
    return {"rich_text":[{"type":"text","text":{"content": val or ""}}]}

def is_empty_prop(prop: dict) -> bool:
    t = prop.get("type")
    if t == "title":
        return len(prop.get("title", [])) == 0
    if t == "rich_text":
        return len(prop.get("rich_text", [])) == 0
    if t == "number":
        return prop.get("number") is None
    if t == "url":
        return not prop.get("url")
    if t == "select":
        return prop.get("select") is None
    if t == "multi_select":
        return len(prop.get("multi_select", [])) == 0
    return False

def build_updates(props: dict, gus: dict, force: bool) -> dict:
    updates = {}
    def put(name, val, title=False):
        if title:
            updates[name] = {"title":[{"type":"text","text":{"content": val or ""}}]}
        else:
            updates[name] = rtext(val or "")

    # Mapowanie nazw właściwości Notion -> wartości z GUS
    if force or is_empty_prop(props.get("Firma", {})):           put("Firma", gus["firma"], title=True)
    if force or is_empty_prop(props.get("REGON", {})):           put("REGON", gus["regon"])
    if force or is_empty_prop(props.get("PKD", {})):             put("PKD", gus["pkd"])
    if force or is_empty_prop(props.get("Ulica", {})):           put("Ulica", gus["ulica"])
    if force or is_empty_prop(props.get("Kod pocztowy", {})):    put("Kod pocztowy", gus["kod"])
    if force or is_empty_prop(props.get("Miasto", {})):          put("Miasto", gus["miasto"])
    if force or is_empty_prop(props.get("Województwo", {})):     put("Województwo", gus["woj"])
    return updates

def get_prop_text(props: dict, name: str) -> str:
    p = props.get(name, {})
    t = p.get("type")
    if t == "title":
        return "".join(x.get("plain_text","") for x in p.get("title", []))
    if t == "rich_text":
        return "".join(x.get("plain_text","") for x in p.get("rich_text", []))
    if t == "number":
        n = p.get("number")
        return "" if n is None else str(n)
    return ""

def get_notion() -> Client:
    token = os.getenv("NOTION_TOKEN") or os.getenv("NOTION_API_TOKEN")
    if not token:
        raise RuntimeError("Brak NOTION_TOKEN/NOTION_API_TOKEN w zmiennych środowiskowych")
    return Client(auth=token)

def get_db_id() -> str:
    db_id = os.getenv("NOTION_DB_ID") or os.getenv("NOTION_DATABASE_ID")
    if not db_id:
        raise RuntimeError("Brak NOTION_DB_ID/NOTION_DATABASE_ID w zmiennych środowiskowych")
    return db_id
