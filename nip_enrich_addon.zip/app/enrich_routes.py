
import os, json, asyncio
from pathlib import Path
from fastapi import APIRouter
from fastapi.responses import HTMLResponse, JSONResponse
from notion_client.errors import APIResponseError
from .gus_enrich import (
    clean_nip, page_id_from_url, fetch_gus,
    build_updates, get_prop_text, get_notion, get_db_id
)

enrich_router = APIRouter()

@enrich_router.get("/enrich-ui")
def enrich_ui():
    tpl = Path(__file__).parent / "templates" / "enrich_ui.html"
    return HTMLResponse(tpl.read_text(encoding="utf-8"))

@enrich_router.post("/notion/enrich-one")
async def notion_enrich_one(payload: dict):
    try:
        q = (payload.get("q") or "").strip()
        force = str(payload.get("force_overwrite", "false")).lower() == "true"

        nip = clean_nip(q)
        page_url = q if q.startswith("http") else ""
        page_id = page_id_from_url(page_url) if page_url else ""

        notion = get_notion()
        db_id = get_db_id()

        # Ustal page_id jeśli mamy NIP
        if not page_id and nip:
            # najpierw traktuj NIP jako tekst (rich_text)
            try:
                r = notion.databases.query(
                    database_id=db_id,
                    filter={"property":"NIP","rich_text":{"contains": nip}},
                    page_size=1
                )
                if r.get("results"):
                    page_id = r["results"][0]["id"]
            except APIResponseError:
                pass
            # fallback: NIP jako number
            if not page_id:
                try:
                    r = notion.databases.query(
                        database_id=db_id,
                        filter={"property":"NIP","number":{"equals": int(nip)}},
                        page_size=1
                    )
                    if r.get("results"):
                        page_id = r["results"][0]["id"]
                except Exception:
                    pass

        if not page_id:
            return JSONResponse({"ok": False, "msg": "Podaj NIP lub URL strony Notion."}, status_code=400)

        page = notion.pages.retrieve(page_id=page_id)
        props = page["properties"]

        # Jeśli nie mamy NIP po wejściu URL, spróbuj zczytać z właściwości strony
        if not nip:
            nip = clean_nip(get_prop_text(props, "NIP"))
            if not nip:
                return JSONResponse({"ok": False, "msg": "Rekord nie ma poprawnego NIP."}, status_code=422)

        gus = await fetch_gus(nip)
        if not gus or not gus.get("firma"):
            return JSONResponse({"ok": False, "msg": f"Brak danych GUS dla NIP {nip}."}, status_code=422)

        updates = build_updates(props, gus, force)
        if updates:
            notion.pages.update(page_id=page_id, properties=updates)

        return {"ok": True, "page_id": page_id, "nip": nip, "updated_fields": list(updates.keys())}
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)
