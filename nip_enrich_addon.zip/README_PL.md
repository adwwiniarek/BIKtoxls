
# Dodatek: Uzupełnianie Notion po NIP (klikany, na żądanie)

Ten dodatek dokłada do Twojego serwisu (BIK→XLS / FastAPI) dwa endpointy:
- **GET `/enrich-ui`** – prosty panel HTML do ręcznego „kliknięcia”
- **POST `/notion/enrich-one`** – API przyjmujące `q` (NIP lub URL strony Notion) i `force_overwrite`

Dane są pobierane z `https://api.officeblog.pl/gus.php?NIP=<NIP>&format=2` i wpisywane do właściwości w Notion:
`Firma` (Title), `REGON`, `PKD`, `Ulica`, `Kod pocztowy`, `Miasto`, `Województwo`.

---

## Krok po kroku (w istniejącym repo z serwisem FastAPI)

1. **Skopiuj pliki** z folderu `app/` do katalogu `app/` w Twoim repo:
   - `app/enrich_routes.py`
   - `app/gus_enrich.py`
   - `app/templates/enrich_ui.html` (utwórz folder `templates` jeśli go nie masz)

2. **Podłącz router** w Twoim `app/server.py` (tu tworzysz `FastAPI()`):
   ```python
   # na górze, razem z innymi importami
   from app.enrich_routes import enrich_router

   # po utworzeniu obiektu app = FastAPI(...)
   app.include_router(enrich_router)
   ```

3. **Zależności** – upewnij się, że pliki są obecne w `requirements.txt`:
   ```txt
   fastapi
   uvicorn
   httpx
   notion-client
   ```

4. **Zmienne środowiskowe** (Render → Dashboard → Service → Environment):
   - `NOTION_TOKEN` – token integracji Notion (Internal Integration)
   - `NOTION_DATABASE_ID` **albo** `NOTION_DB_ID` – ID bazy Notion z klientami
   - (opcjonalnie) `OFFICEBLOG_API_BASE` – domyślnie `https://api.officeblog.pl/gus.php`

5. **Notion (raz)**:
   - Utwórz **Internal Integration** (https://www.notion.so/my-integrations), skopiuj token.
   - Otwórz bazę klientów → **Share** → dodaj integrację → daj dostęp (`Can edit`). 
   - Skopiuj **Database ID** (z URL lub przez eksport API).

6. **Deploy**:
   - Wypchnij commit do GitHub – Render zbuduje serwis (jak przy BIK→XLS).
   - Po starcie wejdź na `https://<twoj-serwis>/enrich-ui`.

7. **Użycie (UI)**:
   - Wpisz **NIP** (np. `1080009072`) **lub** wklej **URL strony w Notion**.
   - Zaznacz „Nadpisz istniejące pola”, jeśli chcesz nadpisać wypełnione.
   - Kliknij **Uzupełnij** – w panelu zobaczysz wynik JSON.

8. **Użycie (API)**:
   ```bash
   curl -X POST https://<twoj-serwis>/notion/enrich-one          -H "Content-Type: application/json"          -d '{"q":"1080009072","force_overwrite":"false"}'
   ```

9. **Dopasowanie nazw pól**:
   Jeśli Twoja baza ma inne nazwy właściwości Notion, zaktualizuj mapowanie w
   `app/gus_enrich.py` → funkcja `build_updates()`.

---

## Najczęstsze błędy i rozwiązania

- **Brak NOTION_TOKEN/DB_ID** – ustaw zmienne środowiskowe w Render.
- **403 w Notion** – integracja nie ma dostępu do bazy → „Share” w Notion dla integracji.
- **„Brak danych GUS dla NIP”** – sprawdź NIP lub dane w rejestrze.
- **Nic nie uzupełnia** – jeśli pola są już wypełnione, odznacz/ustaw `force_overwrite=true`.

---

## Minimalny test lokalny

Jeśli chcesz, możesz uruchomić lokalnie (Python 3.11+):

```bash
pip install -r requirements.txt
export NOTION_TOKEN="secret_xxx"
export NOTION_DATABASE_ID="xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
uvicorn app.server:app --reload
```

Następnie: http://127.0.0.1:8000/enrich-ui
